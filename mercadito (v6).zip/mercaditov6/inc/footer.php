<div class="ResForm"></div>
<div class="ResbeforeSend"></div>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <h4 class="text-footer">Contactanos</h4>
                <a href="https://www.facebook.com" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true">&nbsp; Facebook </i> 
                </a><br>
                <a href="https://www.twitter.com" target="_blank">
                    <i class="fa fa-twitter" aria-hidden="true">&nbsp; Twitter </i>
                </a><br>
                <a href="https://www.youtube.com" target="_blank">
                    <i class="fa fa-youtube-play" aria-hidden="true">&nbsp; YouTube </i>
                </a><br>
                <a href="https://www.instagram.com" target="_blank">
                    <i class="fa fa-instagram" aria-hidden="true">&nbsp; Instagram </i>
                </a><br>
                <a href="https://goo.gl/maps/AmL3HdXMgkrKsYba7" target="_blank">
                    <i class="fa fa-map-marker" aria-hidden="true">&nbsp; Encuentranos </i>
                </a>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer">Acerca del MERCADITO</h4>
                <p> 
                    Somos una empresa dedicada a la venta de frutas y verduras.</br>
                    Vas a adquirir productos frescos de alta calidad.</br>
                    Eligiendo lo que requieres y alistando tu pedido para posteriormente ser recibido.</br>
                    Gracias por preferirnos!.</br>
                </p>
            </div>
            <div class="col-sm-4">
                <h4 class="text-footer" >Direccion</h4>
                <p style="color: #FFF">Costa Rica</p>
                <p style="color: #FFF">Heredia, San Jose, Cartago</p>
                <p style="font-size:20px" aria-hidden="true">  506 – 2233 – 4040</p>
                <p class="fa fa-mobile" style="font-size:20px"  aria-hidden="true">  506 / 8576 – 8900</p> <a href="https://wa.link/xkavgs" target="_blank" style="color: #5bc0de">envianos_un_mensaje</a></br>
                E-mail: <a href="mailto:frutasyverduras@mercadito.com?Subject=Requiero%20informacion%20del%20mercadito" target="_blank" style="color: #5bc0de"> &nbsp; frutasyverduras@mercadito.com</a>
            </div>
        </div>
    </div>
    <br><br><br>
    <h5 class="text-center tittles-pages-logo text-footer">MERCADITO &copy; 2021</h5>
</footer>
